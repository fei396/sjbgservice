﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sjbgWebService
{
    public class ZbPerson
    {
        public string Workno { get; set; }
        public string Name { get; set; }
        public string Dept { get; set; }
        public string Date { get; set; }
        public string DayNight { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string signTime { get; set; }
    }
}