﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sjbgWebService
{
    public class FeiYunYongJiChe
    {
        public string JiCheLeiXing { get; set; }
        public string JiCheBianHao { get; set; }
        public string ZhuangTai { get; set; }
        public string DiDian { get; set; }
        public string ZhuanRuShiJian { get; set; }
        public string ZhuanChuShiJian { get; set; }
        public string GongZuoShiJian { get; set; }
    }
}