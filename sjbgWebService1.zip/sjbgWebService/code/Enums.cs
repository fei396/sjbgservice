﻿namespace sjbgWebService.pub
{
	public enum uLevel { DuanZhang, ShuJi, FuDuan, ZhuRen, ShuJu, KeZhang, None }
}

namespace sjbgWebService.gwxx
{
	public enum gwlx { DQ,XZ,ALL  }
	public enum dwlx { LJ, DW,ALL }

}
namespace sjbgWebService.zbxt
{
}