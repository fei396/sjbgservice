﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sjbgWebService
{
    public class JianBao
    {
        public String BuMen { get; set; }
        public String XiangMu { get; set; }
        public String NeiRong { get; set; }
        public String Date { get; set; }
        public int BmOrders { get; set; }
    }
}