﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sjbgWebService
{
    public class GpsData
    {
        public string work_no { get; set; }
        public string work_name { get; set; }
        public string Jingdu { get; set; }
        public string Weidu { get; set; }
        public string Weizhi { get; set; }
        public string Shijian { get; set; }
    }
}